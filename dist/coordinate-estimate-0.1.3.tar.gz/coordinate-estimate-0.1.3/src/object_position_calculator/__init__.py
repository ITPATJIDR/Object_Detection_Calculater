from .object_position import DroneYOLOClient
from .detect_object import YOLOTracker
from .newCalculator import newCoordinateCalculator